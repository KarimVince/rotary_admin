# Handoff: Rotary Club of Discovery Bay — Meeting Attendance Report

## Overview

A single-page, print-first attendance sheet for the club's weekly meeting. It is filled in by hand at the meeting (or generated pre-filled from the member roll) and records: which members attended, who paid, which visiting Rotarians and guests came, and a closing tally of headcount and meeting finances.

Replaces an earlier ReportLab-generated PDF that ran to two pages with a large amount of dead space.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes showing the intended look and print behaviour. They are **not production code to copy directly**.

The task is to **recreate this design in the target codebase's existing environment** (React, Vue, Django templates, a ReportLab/WeasyPrint generator, etc.) using its established patterns, component library, and PDF pipeline. If no environment exists yet, choose the framework most appropriate for the project and implement the design there.

The current production artefact is a **PDF generated server-side by ReportLab**. If that stays, treat this bundle as the visual spec to reimplement in ReportLab platypus flowables (or switch to an HTML→PDF renderer such as WeasyPrint/Playwright, which will match this spec far more cheaply).

## Fidelity

**High-fidelity.** Colours, typography, spacing, and dimensions below are final and exact. Recreate the layout precisely, substituting the codebase's own primitives where equivalents exist.

## Page Geometry

- Target sheet: **US Letter portrait**, 8.5in × 11in.
- Design canvas: **816 × 1056 px** at 96 dpi (1px = 1/96in ≈ 0.75pt).
- Page padding: **36px top/bottom, 46px left/right** → content column **724px** wide.
- The page is a vertical flex column; the tally/signature block is pushed to the bottom with `margin-top:auto`.
- At the default row counts (6 visiting Rotarians, 5 guests) the sheet fills exactly one page. **The document must be allowed to flow onto additional pages** as the member roll and visitor lists grow — do not clip or force-fit.

## Screens / Views

There is one view: the printable report. It has six stacked blocks.

### 1. Masthead

Horizontal flex row, `align-items:center`, `gap:22px`.

| Element | Spec |
| --- | --- |
| Club emblem (left) | `assets/rcdb-logo.png`, height **60px**, width auto |
| Title | "Attendance Report" — Archivo **800**, **25px**, line-height 1.05, letter-spacing −0.015em, colour `--navy` `#0c2340`, margin 0 |
| Subtitle | "Weekly Meeting · Rotary Club of Discovery Bay · District 3450, Hong Kong" — Archivo 400, **11px**, colour `--slate` `#6b7686`, margin-top 4px |
| Rotary lockup (right) | `assets/rotary-lockup.png`, height **40px**, width auto |

The title/subtitle block is `flex:1 1 auto; min-width:0` so the two logos sit at the outer edges.

Below the masthead: a **2px** full-width bar in `--azure` `#17458f`, `margin-top:14px`.

### 2. Meeting meta strip

Flex row, `justify-content:space-between`, background `--tint` `#e3edfb`, border-radius **4px**, padding **9px 14px**, margin-top 12px.

Left cluster (`gap:12px`):
- Pill "MEETING" — white background, `--azure` text
- Date "7 July 2026" — Archivo 800, 13px
- Venue "Peoni — Discovery Bay" — 11px, `--slate`

Right cluster (`gap:12px`, `white-space:nowrap`, base 11px `--slate`):
- Pill "PAYMENT" — `--gold-bg` `#fdf0da` background, `--gold` `#b87610` text
- "Cash or FPS" — weight 700, `--navy`
- "FPS ID **108236613**" — the number bold, `--navy`, `font-variant-numeric:tabular-nums`

**Pill spec (all pills):** inline-flex, height **19px**, padding `0 9px`, border-radius **10px**, font-size **9.5px**, weight 800, letter-spacing 0.07em, uppercase.

### 3. Section headers (shared pattern)

Flex row, `justify-content:space-between`, margin `14px 0 6px`.
- Label: **11px**, weight 800, letter-spacing **0.12em**, uppercase, `--navy`.
- Optional pill immediately right of the label (`gap:10px`).
- Right-hand note: **10.5px**, `--slate-2` `#9aa7ba`.

Three instances:

| Section | Label | Pill | Note |
| --- | --- | --- | --- |
| Members | MEMBERS | — | "17 on roll · tick attendance and payment" |
| Visiting Rotarians | VISITING ROTARIANS | "GUEST CLUB" (`--tint` bg / `--azure` text) | "Payment only" |
| Guests | GUESTS | "HOSTED" (`--violet-bg` `#ece7fb` bg / `--violet` `#5b3fa0` text) | "Payment only" |

### 4. Members table — two columns

Wrapper: `display:grid; grid-template-columns:1fr 1fr; gap:16px`. The 17-name roll is split with `Math.ceil(n/2)` in the left column (rows 1–9) and the remainder in the right (rows 10–17). **Splitting into two columns is the key layout decision** — it removes the wasted horizontal space that a single full-width name column produced.

Each column is a table card:
- Card: background `#fff`, border `1px solid --rule #dde3ec`, border-radius **6px**, `overflow:hidden`, `display:flex; flex-direction:column`.
- Header row: `display:grid`, background `--azure`, height **26px**, `flex:0 0 26px`.
- Header cells: 10px horizontal padding, font-size **9px**, weight 800, letter-spacing 0.1em, uppercase, colour `#fff` at `opacity:.92`. Checkbox-column headers are centred with 0 padding.
- Body rows: `display:grid`, height **26px**, `flex:0 0 26px`, `border-top:1px solid --hair #eef1f6`.
- Zebra: odd rows get background `--zebra` `#f6f9fd`.
- Column template: **`26px 1fr 40px 40px`** (#, Member, Att, Pay).

Cells:
- Index: centred, 0 padding, **10px**, `--slate-2`, tabular-nums.
- Name: 10px padding, **12px**, `--navy`, `white-space:nowrap; overflow:hidden; text-overflow:ellipsis`.
- Checkbox cells: centred, 0 padding, with `border-left:1px solid --hair`.

**Checkbox spec:** 15 × 15px, `border:1.5px solid --azure`, border-radius **2px**, background `#fff`, `flex:0 0 auto`. Empty — ticked by hand. If the report is ever made interactive, use a real `<input type="checkbox">` styled to this spec with an azure check glyph.

Member roll (order as listed, alphabetical by surname):

```
1  Berrada Karim Vincent          10  Herbet Jean-Charles
2  Chasset Christian              11  Herbet Patrick Marie
3  Chasset Dominique              12  Martin Catya
4  Chow II Agnes                  13  Martin Jean-Roch
5  De Clarens Jerome              14  Rensinghoff-Schmelzer Xenia A.I
6  Ding Tian                      15  Rotmeyer Jeff
7  Fong Michael                   16  Sarrazin-Boesplug Thibaud
8  Goerig-Caillé Pauline          17  Sicard Nicole
9  Gry Jean-Philippe
```

### 5. Visiting Rotarians and Guests tables

Both full-width, same card and header treatment as the members table, but:
- Column template: **`1.15fr 1fr 52px`**.
- Row height **27px** (`.tbl.wide .tr`) — slightly taller because these rows are written into by hand.
- **One checkbox column only — Pay.** There is deliberately no Attendance column: a visitor or guest listed on the sheet was by definition present.
- Rows are blank; the wide Name and Club / Host Rotarian columns exist to be handwritten.

| Table | Columns | Default blank rows |
| --- | --- | --- |
| Visiting Rotarians | Name, Club, Pay | **6** (minimum 5, must be configurable upward) |
| Guests | Name, Host Rotarian, Pay | **5** (minimum 5, must be configurable upward) |

### 6. Tally and signature block

Pushed to the page bottom (`margin-top:auto; padding-top:10px`).

Two equal groups side by side in a flex row with `gap:18px`; each group is `display:grid; grid-template-columns:repeat(4,1fr); gap:8px`.

Box spec: `border:1px solid --rule`, border-radius **6px**, padding **7px 9px**.
- Label: **8.5px**, weight 800, letter-spacing 0.09em, uppercase.
- Write-in line below: height **18px**, `border-bottom:1.5px solid`, margin-top 4px.

| Group | Background | Label colour | Rule colour | Boxes |
| --- | --- | --- | --- | --- |
| Attendance | `--zebra` `#f6f9fd` | `--slate` | `--rule` `#dde3ec` | Members, Visitors, Guests, Total |
| Finance | `--gold-bg` `#fdf0da` | `--gold` `#b87610` | `#e8d3ad` | Paid, Revenue, Cost, Result |

The three money boxes (Revenue, Cost, Result) carry a small **"HK$"** marker (9px, `--slate-2`) sitting at the bottom-left of the write-in line. "Paid" is a count, so it has no currency marker.

Signature row below (`margin-top:12px; padding-top:10px; border-top:1px solid --rule`, flex, `align-items:flex-end`, `gap:36px`):
- Two fields, `flex:1` each, `gap:32px`: "Recorded by" and "Signature" — label **10px** `--slate`, each with a full-width `border-bottom:1px solid --slate-2` rule of height 16px beneath.
- Right-aligned colophon: "Rotary Club of Discovery Bay — Attendance Report", **9px**, `--slate-2`, `white-space:nowrap`.

## Interactions & Behavior

The artefact is print-first and has no interactive states in the current design. If it becomes a web form:

- **Checkboxes** — hover: 1px `--azure` outline offset 1px. Checked: fill `--azure`, white check glyph. Focus-visible: `2px solid var(--azure)` outline, 2px offset. Never leave the browser default focus ring.
- **Editable name cells** (visitor/guest rows) — render as borderless text inputs that inherit the 12px `--navy` cell type; focus shows the `--azure` focus ring on the cell.
- **Tally boxes** — if attendance is captured digitally, Members / Visitors / Guests / Total and Paid should compute automatically from the ticked rows; Revenue, Cost and Result remain manual entry, with Result ideally derived as Revenue − Cost.
- **Row growth** — the visitor and guest row counts are parameters, minimum 5, no hard maximum. The page must reflow across sheets rather than clip.
- **Responsive** — not required; this is a fixed-width print document. If shown on screen at narrow widths, collapse the two member columns to one and let the page scroll.

## State Management

For a data-backed implementation:

```
meetingDate: Date
venue: string
paymentMethods: string[]        // ["Cash", "FPS"]
fpsId: string
members: { id, name }[]         // ordered alphabetically by surname
attendance: Record<memberId, { present: boolean, paid: boolean }>
visitors: { name, club, paid }[]        // min 5 blank slots when printing
guests:   { name, hostRotarian, paid }[] // min 5 blank slots when printing
tally: { members, visitors, guests, total, paid }        // derivable
finance: { revenue: number, cost: number, result: number } // HKD, manual
```

Derived values: `total = members + visitors + guests`; `result = revenue − cost`; the members column split is `Math.ceil(members.length / 2)`.

Data source: the club roll and meeting calendar (the existing "Dinner & Fellowship Calendar" report draws on the same meeting records — reuse that data layer if it exists).

## Design Tokens

Palette taken from the club's existing Rotary-branded reports.

```
--navy       #0c2340   headings, body text in tables
--azure      #17458f   table header fill, masthead rule, checkbox border, accents
--slate      #6b7686   secondary text, labels
--slate-2    #9aa7ba   tertiary text, row indices, signature rules
--rule       #dde3ec   card borders, tally box borders and write-in rules
--hair       #eef1f6   in-table row and column dividers
--zebra      #f6f9fd   odd-row striping, attendance tally boxes
--tint       #e3edfb   meta strip fill, "Guest Club" pill
--gold       #b87610   finance labels, "Payment" pill text
--gold-bg    #fdf0da   finance box and "Payment" pill fill
--gold-rule  #e8d3ad   finance write-in rules
--violet     #5b3fa0   "Hosted" pill text
--violet-bg  #ece7fb   "Hosted" pill fill
```

**Typography — Archivo** (Google Fonts, weights 400/700/800). Weight 800 for all headings, labels and pills.

| Role | Size | Weight | Tracking |
| --- | --- | --- | --- |
| Page title | 25px | 800 | −0.015em |
| Masthead subtitle | 11px | 400 | — |
| Meeting date | 13px | 800 | — |
| Section label | 11px | 800 | 0.12em, uppercase |
| Section note | 10.5px | 400 | — |
| Table header cell | 9px | 800 | 0.1em, uppercase |
| Table body cell | 12px | 400 | — |
| Row index | 10px | 400 | tabular-nums |
| Pill | 9.5px | 800 | 0.07em, uppercase |
| Tally label | 8.5px | 800 | 0.09em, uppercase |
| Signature / currency | 9–10px | 400 | — |

**Spacing:** 4 · 6 · 8 · 10 · 12 · 14 · 16 · 18 · 22 · 26 · 36 · 46 px.
**Radii:** 2px (checkbox) · 4px (meta strip) · 6px (cards, tally boxes) · 10px (pills).
**Row heights:** 26px header · 26px member row · 27px visitor/guest row.
**Shadows:** none — the design is flat; separation comes from 1px borders and the azure header fill.

## Assets

| File | Description | Origin |
| --- | --- | --- |
| `assets/rcdb-logo.png` | Club emblem, 700 × 547px — navy/blue roundel over "ROTARY CLUB / Of Discovery Bay ▮ Hong Kong" | Extracted from the club's existing attendance PDF |
| `assets/rotary-lockup.png` | "Rotary / Club of Discovery Bay" horizontal lockup with the gold Rotary International wheel, 1379 × 527px | Supplied by the club |

Both are official Rotary brand marks — use them as-is at the heights specified, never recoloured, distorted, or placed on a coloured field. Icons elsewhere: none currently; if any are added use [Lucide](https://lucide.dev).

## Files

| File | What it is |
| --- | --- |
| `attendance-report.html` | **Primary reference.** Self-contained static HTML + CSS of the finished design. Open in a browser; print preview shows the Letter page. Class names match the specs above. |
| `Attendance Report.dc.html` | The working design-tool source. Same markup, but templated (member roll and blank-row counts come from a small logic class) — useful for seeing how the data drives the layout. |
| `assets/rcdb-logo.png` | Club emblem. |
| `assets/rotary-lockup.png` | Rotary lockup. |

## Implementation Notes / Gotchas

- **Whitespace in flex/grid table bodies.** The tables are flex columns with fixed-height rows. Building them as plain block containers lets whitespace text nodes between rows create stray line boxes, which silently inflated every row by ~8px during design. Use flex or a real `<table>`; don't hand-space block rows.
- **Beware `.card` class collisions** if the target codebase has its own `.card` with padding/gap — the design's table wrapper is named `.tbl` for exactly this reason.
- **Print sizing.** Fixed 816px width and 96dpi assumptions apply to screen preview only. For the real PDF, drive layout from the page box (`@page { size: letter; margin: 0 }`) and let the content flow; do not hard-pin heights.
- **Tabular numerals** on the FPS ID and row indices keep columns aligned — carry `font-variant-numeric: tabular-nums` across.
- **Attendance is deliberately absent** from the visitor and guest tables. Don't "restore" it for symmetry.
